﻿using System;
using System.Runtime.CompilerServices;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}

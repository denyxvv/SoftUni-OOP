﻿namespace _04.BorderControl
{
    public interface IBirthdatable
    {
        string BirthDate { get; set; }
        string BirthYearOnly { get; }
    }
}
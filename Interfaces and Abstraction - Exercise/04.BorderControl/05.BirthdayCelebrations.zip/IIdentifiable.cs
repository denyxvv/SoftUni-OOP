﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl
{
    public interface IIdentifiable
    {
        string Name { get; }
        string Id { get; }
        void Check(string fakeString);
    }
}
